<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68daeb73301dc             |
    |_______________________________________|
*/
 use Pmpr\Module\Rating\Rating; Rating::symcgieuakksimmu();
