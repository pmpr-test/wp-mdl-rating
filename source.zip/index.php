<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670531a813b00             |
    |_______________________________________|
*/
 use Pmpr\Module\Rating\Rating; Rating::symcgieuakksimmu();
