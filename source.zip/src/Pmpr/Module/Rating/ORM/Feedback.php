<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19b4308b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\ORM; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Feedback extends Common { public function register() { $this->muuwuqssqkaieqge(__("\106\x65\145\x64\142\x61\143\x6b\x73", PR__MDL__RATING))->guiaswksukmgageq(__("\106\145\x65\x64\142\x61\x63\153", PR__MDL__RATING))->saemoowcasogykak(IconInterface::aessmsgaooqooygy); } }
