<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7b8be7a5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\ORM; use Pmpr\Module\Rating\Container; class ORM extends Container { public function aqyikqugcomoqqqi() { Rate::symcgieuakksimmu(); Feedback::symcgieuakksimmu(); } }
