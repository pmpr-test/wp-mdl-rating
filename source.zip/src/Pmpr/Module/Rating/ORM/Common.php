<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19b4308b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\ORM; use Pmpr\Common\Foundation\_ORM\Model; abstract class Common extends Model { }
