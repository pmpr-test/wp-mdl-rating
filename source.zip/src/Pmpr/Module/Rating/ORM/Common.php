<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec8958dde             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\ORM; use Pmpr\Common\Foundation\_ORM\ORMObject; abstract class Common extends ORMObject { }
