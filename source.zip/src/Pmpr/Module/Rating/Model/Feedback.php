<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19b4308b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Feedback extends Common { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::aessmsgaooqooygy)->guiaswksukmgageq(__("\106\x65\x65\x64\x62\141\143\153", PR__MDL__RATING))->muuwuqssqkaieqge(__("\x46\145\145\x64\x62\x61\x63\x6b\x73", PR__MDL__RATING))->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::TEXT)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x54\x65\170\164", PR__MDL__RATING))); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->uccuieiyckcoaqsk()->mkksewyosgeumwsa($this->mccagaqeagiikkec(Constants::iockmgiyoygcswog)->umokgsqqogccoouo())->mkksewyosgeumwsa($this->mccagaqeagiikkec(Constants::mswoacegomcucaik)->ukqywcsoogkyoaoa()))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(Constants::ioksewgkgwwikiwo)->ucwmaimegouwwocg())->mkksewyosgeumwsa($this->sciaycsmsiekqueg(Constants::TEXT)); } }
